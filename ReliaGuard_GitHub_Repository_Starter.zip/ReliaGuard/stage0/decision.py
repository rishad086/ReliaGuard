"""Frozen Stage-0 routing rule (calibration intentionally unchanged)."""
STAGE0_THRESHOLD=0.13

def is_flagged(presence_score):
    return float(presence_score) >= STAGE0_THRESHOLD
