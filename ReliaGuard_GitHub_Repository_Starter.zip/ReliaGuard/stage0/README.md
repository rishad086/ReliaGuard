# Stage 0: OCR-layout screening

- `layout6.py` contains the original six OCR polygon features extracted from
  notebook A5, with the EasyOCR reader made an explicit argument.
- `decision.py` encodes the frozen 0.13 operating point.
- Classifier weights are NOT in the public package by default; use the exact
  historical `stage0_layout6_gradientboosting_FINAL_REBUILT.pkl` checkpoint
  after verifying its integrity and the required `scikit-learn==1.6.1`.

**Security:** only load `joblib` / `.pkl` files obtained from sources you trust.
