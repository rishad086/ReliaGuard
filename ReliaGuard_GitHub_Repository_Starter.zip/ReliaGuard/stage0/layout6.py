# Extracted from original A5 implementation (exact six OCR polygon features).
# Only adaptation: pass the existing EasyOCR reader explicitly rather than using a global.
# Requires cv2, numpy, an already constructed EasyOCR Reader.
import cv2
import numpy as np

LAYOUT6_FEATURES = (
    "text_area_ratio", "largest_box_area_ratio", "mean_box_area_ratio",
    "max_box_height_ratio", "mean_box_height_ratio", "central_text_fraction",
)

def extract_ocr_layout_features(image_input, reader):

    # --------------------------------------------------------
    # Accept either:
    #   - image filepath
    #   - PIL image
    # --------------------------------------------------------

    if isinstance(image_input, str):

        image_bgr = cv2.imread(
            image_input
        )

    else:

        image_rgb = np.array(
            image_input
        )

        image_bgr = cv2.cvtColor(
            image_rgb,
            cv2.COLOR_RGB2BGR
        )


    if image_bgr is None:

        raise ValueError(
            "Could not load image."
        )


    # --------------------------------------------------------
    # Image dimensions
    # --------------------------------------------------------

    h, w = image_bgr.shape[:2]

    image_area = float(
        h * w
    )


    # --------------------------------------------------------
    # Run EasyOCR
    # --------------------------------------------------------

    ocr_results = reader.readtext(
        image_bgr
    )


    # --------------------------------------------------------
    # If no OCR text exists
    # --------------------------------------------------------

    if len(ocr_results) == 0:

        return {

            "text_area_ratio":
                0.0,

            "largest_box_area_ratio":
                0.0,

            "mean_box_area_ratio":
                0.0,

            "max_box_height_ratio":
                0.0,

            "mean_box_height_ratio":
                0.0,

            "central_text_fraction":
                0.0,

            "num_ocr_regions":
                0
        }


    # --------------------------------------------------------
    # Raw OCR mask
    #
    # This mask represents the actual OCR polygons.
    # No dilation is applied for Stage-0 layout features.
    # --------------------------------------------------------

    raw_mask = np.zeros(
        (h, w),
        dtype=np.uint8
    )


    box_areas = []
    box_heights = []


    # --------------------------------------------------------
    # Process every OCR polygon
    # --------------------------------------------------------

    for result in ocr_results:

        bbox = np.array(
            result[0],
            dtype=np.float32
        )


        # Keep polygon coordinates inside image bounds

        bbox[:, 0] = np.clip(
            bbox[:, 0],
            0,
            w - 1
        )

        bbox[:, 1] = np.clip(
            bbox[:, 1],
            0,
            h - 1
        )


        polygon = bbox.astype(
            np.int32
        )


        # Add polygon to OCR union mask

        cv2.fillPoly(
            raw_mask,
            [polygon],
            255
        )


        # ----------------------------------------------------
        # OCR box area
        # ----------------------------------------------------

        area = float(
            cv2.contourArea(
                bbox
            )
        )

        box_areas.append(
            max(
                area,
                0.0
            )
        )


        # ----------------------------------------------------
        # OCR box vertical extent
        # ----------------------------------------------------

        box_height = float(
            bbox[:, 1].max()
            -
            bbox[:, 1].min()
        )

        box_heights.append(
            max(
                box_height,
                0.0
            )
        )


    # ========================================================
    # FEATURE 1
    # TEXT AREA RATIO
    # ========================================================

    text_pixels = int(
        np.count_nonzero(
            raw_mask
        )
    )


    text_area_ratio = (
        text_pixels
        /
        image_area
    )


    # ========================================================
    # FEATURE 2
    # LARGEST OCR BOX AREA RATIO
    # ========================================================

    largest_box_area_ratio = (
        max(box_areas)
        /
        image_area
    )


    # ========================================================
    # FEATURE 3
    # MEAN OCR BOX AREA RATIO
    # ========================================================

    mean_box_area_ratio = (
        np.mean(box_areas)
        /
        image_area
    )


    # ========================================================
    # FEATURE 4
    # MAXIMUM BOX HEIGHT RATIO
    # ========================================================

    max_box_height_ratio = (
        max(box_heights)
        /
        h
    )


    # ========================================================
    # FEATURE 5
    # MEAN BOX HEIGHT RATIO
    # ========================================================

    mean_box_height_ratio = (
        np.mean(box_heights)
        /
        h
    )


    # ========================================================
    # FEATURE 6
    # CENTRAL TEXT FRACTION
    #
    # Central region = middle 50% of image
    # ========================================================

    x1 = int(
        0.25 * w
    )

    x2 = int(
        0.75 * w
    )

    y1 = int(
        0.25 * h
    )

    y2 = int(
        0.75 * h
    )


    center_mask = np.zeros(
        (h, w),
        dtype=np.uint8
    )


    center_mask[
        y1:y2,
        x1:x2
    ] = 255


    central_text_pixels = int(
        np.count_nonzero(
            (raw_mask > 0)
            &
            (center_mask > 0)
        )
    )


    central_text_fraction = (
        central_text_pixels
        /
        text_pixels
        if text_pixels > 0
        else 0.0
    )


    # --------------------------------------------------------
    # Return features
    # --------------------------------------------------------

    return {

        "text_area_ratio":
            float(
                text_area_ratio
            ),

        "largest_box_area_ratio":
            float(
                largest_box_area_ratio
            ),

        "mean_box_area_ratio":
            float(
                mean_box_area_ratio
            ),

        "max_box_height_ratio":
            float(
                max_box_height_ratio
            ),

        "mean_box_height_ratio":
            float(
                mean_box_height_ratio
            ),

        "central_text_fraction":
            float(
                central_text_fraction
            ),

        # Diagnostic only.
        # NOT one of the six final Stage-0 model features.
        "num_ocr_regions":
            int(
                len(ocr_results)
            )
    }


def feature_row(image, reader):
    f = extract_ocr_layout_features(image, reader)
    return [float(f[k]) for k in LAYOUT6_FEATURES]
