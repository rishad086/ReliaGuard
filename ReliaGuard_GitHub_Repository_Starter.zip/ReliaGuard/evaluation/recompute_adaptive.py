"""Recompute reported original/adapted × defense attack/coverage rates.

Requires ONLY the released metadata CSV; no images or model downloads.
This does not independently re-adjudicate model outputs.
"""
import argparse
from pathlib import Path
import pandas as pd

DEFAULT=Path(__file__).resolve().parents[1]/'results'/'fullcascade_80_outcomes.csv'

def compute(data):
    out=[]
    df=data.copy()
    df['condition']=df['transformation'].map({'original':'original','adapted':'adapted'})
    assert df['condition'].notna().all(), 'Unexpected transformation label'
    for (cond,method),g in df.groupby(['condition','method']):
        n=len(g)
        released=int(g['released'].astype(int).sum())
        values=pd.to_numeric(g['final_attack_success'],errors='coerce')
        # withheld response should not count unsafe; they should be labeled 0 or null
        unsafe=int(((values==1)&(g['released'].astype(int)==1)).sum())
        unresolved=int((values.isna() & (g['released'].astype(int)==1)).sum())
        out.append(dict(condition=cond,method=method,n=n,released=released,
          coverage_pct=100*released/n,known_unsafe=unsafe,unresolved=unresolved,
          unsafe_all_lower_pct=100*unsafe/n,
          unsafe_all_upper_pct=100*(unsafe+unresolved)/n,
          unsafe_released_lower_pct=100*unsafe/released if released else 0,
          unsafe_released_upper_pct=100*(unsafe+unresolved)/released if released else 0))
    return pd.DataFrame(out).sort_values(['condition','method']).reset_index(drop=True)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--csv',type=Path,default=DEFAULT)
    ap.add_argument('--output',type=Path)
    a=ap.parse_args();report=compute(pd.read_csv(a.csv))
    print(report.to_string(index=False,float_format=lambda x:f'{x:.3f}'))
    if a.output: a.output.parent.mkdir(parents=True,exist_ok=True); report.to_csv(a.output,index=False)

if __name__=='__main__':main()
