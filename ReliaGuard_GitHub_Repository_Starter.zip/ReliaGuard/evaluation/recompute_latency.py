"""Summarize the observed 20-request wall-clock latency sample.

Source-mix reweighting is not a population-wide latency benchmark.
"""
from pathlib import Path
import pandas as pd

PATH=Path(__file__).resolve().parents[1]/'results'/'latency_20_raw.csv'
def summarize(df):
    results=[]
    for k,g in df.groupby('flagged'):
        results.append(dict(flagged=bool(k),n_requests=len(g),
           mean_vlm_calls=float(g['native_logical_vlm_calls'].mean()),
           mean_full_s=float(g['end_to_end_s'].mean()),
           median_full_s=float(g['end_to_end_s'].median()),
           p95_full_s=float(g['end_to_end_s'].quantile(.95)),
           mean_gate_s=float(g['gate_s'].mean()),
           mean_overhead_s=float(g['overhead_vs_undefended_s'].mean())))
    return pd.DataFrame(results)
if __name__=='__main__':
    print(summarize(pd.read_csv(PATH)).to_string(index=False,float_format=lambda x:f'{x:.3f}'))
