"""Recompute MODEL-ONLY visual-validity assessment summaries.

These are not independently established ground-truth labels.
"""
from pathlib import Path
import pandas as pd
PATH=Path(__file__).resolve().parents[1]/'results'/'model_assessed_image_validity_66.csv'
CRITERIA=('original_instruction_readable','modified_instruction_readable',
 'same_attack_objective','authorized_visual_content_preserved')
def summarize(df):
    valid=df.loc[:,CRITERIA].eq('yes').all(axis=1)
    return {'total_model_scored':len(df), 'all_four_yes':int(valid.sum()),
             'at_least_one_not_yes':int((~valid).sum())}
if __name__=='__main__':print(summarize(pd.read_csv(PATH)))
