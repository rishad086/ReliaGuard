# Recomputable evaluation

These scripts calculate tables from **previously adjudicated records**. They
**do not** rerun the victim VLM, rerun the semantic judge, or supply independent
validation of AI-generated image-validity labels.

```bash
python -m evaluation.recompute_adaptive
python -m evaluation.recompute_latency
python -m evaluation.recompute_validity
```

The 80-source attack records retain source identifiers, release decisions,
semantic labels and adjudication provenance, **without** original prompts,
images, response text or judge explanations.
