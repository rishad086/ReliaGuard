# Data sources, split provenance and permitted reuse

- **CyberSecEval3 Visual Prompt Injection (Meta):**
  https://huggingface.co/datasets/facebook/cyberseceval3-visual-prompt-injection
  The dataset card currently indicates MIT license and benchmark-use
  conditions. Get source images and accompanying prompts directly from the
  original host, review current terms, and avoid silently rehosting images.
- **VQAv2 (Visual Question Answering):**
  https://visualqa.org/download.html
  Access via its official distribution and check the applicable COCO image
  rights and annotation licensing before redistribution.
- **OPI-Bench independent set:**
  https://huggingface.co/datasets/orailix/opi-bench
  Verify the dataset card's current license/usage conditions. No OPI raw
  images are committed in this repository.

`splits/stage0_vpi_*_FROZEN_INDICES.json` provide indices of the archived
CyberSecEval3 partitions; `splits/fullcascade_80_source_ids.csv` records
selected adaptive source IDs and risk groups. Historical split construction
can depend on dataset ordering/version; record the source dataset revision
and/or raw source hashes for future reruns.

The repository does not contain raw CyberSecEval3/VQAv2/OPI images, system
prompts, secrets, VLM model weights or private human-annotation records.
