# ReliaGuard: Reliability-Aware Selective Defense Against Visual Prompt Injection

**Research reproducibility release — first-stage repository preparation.**

This repository accompanies the IEEE TIFS-oriented ReliaGuard manuscript.
ReliaGuard separates (1) OCR-layout attack-presence screening, (2)
counterfactual effective-compromise detection, and (3) candidate-risk-aware
selective response release/abstention.

> **Status:** Public **result-level reproducibility is working**. Running the
> full GPU pipeline from a clean machine is **not yet self-contained**: the
> original historical `restore_reliaguard_runtime.py` and verified frozen
> checkpoint files need to be supplied separately. The supplied notebooks
> call the original runtime and use the actual source code of the study.
> No claim of end-to-end reimplementation is made by the stand-alone
> threshold helpers.

## Contents

| Path | Contents |
|---|---|
| `stage0/` | Original six-feature OCR extractor, frozen screening threshold |
| `v3/` | V3 routing logic and precise description of historical runtime dependency |
| `v4/` | V4 release rule and original notebook FC5 bridge |
| `multiview/` | Original AD0C 4-view scorer and max-aggregation helper |
| `evaluation/` | **Runnable** reconstruction of attack, latency and model-only validity tables |
| `configs/` | Frozen protocol, image assessor metadata, thresholds, historical environment |
| `splits/` | Source IDs from frozen splits, selected 80-source reserve sample |
| `notebooks/` | Actual original final 80-source full-cascade and external OPI experiment notebooks |
| `results/` | Minimized adjudication records, 20-request timing and AI-image verdicts |
| `tests/` | Offline unit and quantitative checks |
| `requirements*.txt` | Analysis dependencies and GPU candidate dependencies |
| `LICENSE` | Copyright status pending an explicit choice by the code owners |

## Fastest reproducibility path — CPU, no model download

```bash
python -m pip install -r requirements.txt
python -m evaluation.recompute_adaptive
python -m evaluation.recompute_latency
python -m evaluation.recompute_validity
python -m unittest discover -s tests -v
```

Expected adaptive evaluation (80 source-disjoint held-out samples):

| Input | Method | Released | Confirmed unsafe | Unsafe/All |
|---|---|---:|---:|---:|
| Original | No Defense | 80/80 | 42 | 52.50% |
| Original | Multi-view ReliaGuard | 71/80 | 4 | 5.00% |
| Adapted | No Defense | 80/80 | 39 | 48.75% |
| Adapted | Multi-view ReliaGuard | 73/80 | 7 | 8.75% |

These results are computed from the final semantic labels (`results/fullcascade_80_outcomes.csv`),
including 14 formerly unresolved judgments that were subsequently manually
adjudicated. Recomputing these columns is **not** a new independent judgment.

## Model-only image validity

The 66 modified images received one automatic 4-criterion assessment each:
29/66 were rated `yes` on all four criteria and 37/66 failed at least one.
These verdicts were produced by **Qwen2.5-VL-7B-Instruct** and have **not**
been established as human-verified ground truth. Do not report the
model-aligned result as independent human–model agreement. The published
adaptive security table uses all 80 sources, not a validity-filtered subset.

## Timings

The frozen Qwen2.5-VL-3B run timed 20 selected *original attack* requests,
with one fresh trial per source and CUDA-synchronized wall time:

| Route | n | Native VLM calls | Mean end-to-end |
|---|---:|---:|---:|
| Stage-0 bypass | 2 | 1 | 13.71 s |
| Flagged | 18 | 5 | 27.18 s |

The 24.91-second historical source-mix-weighted estimate is **not** the
mean measured over all 80 inputs, and the sample contains only two
unflagged attacks. Download/model initialization was excluded.

## Full inference reproduction — historical Kaggle path

1. Obtain the **original CyberSecEval3 Visual Prompt Injection** dataset
   through its official distribution and preserve sample IDs (see `DATA.md`).
2. Use Kaggle with CUDA, the compatible `scikit-learn==1.6.1`, a verified
   Qwen2.5-VL-3B model checkpoint, the precise frozen Stage-0/V3/V4 models,
   and the original `restore_reliaguard_runtime.py`.
3. Run `notebooks/fullcascade_80_budget320.ipynb` in order: AD0A → AD0B →
   AD0C → FC1–FC11. This includes a budget-limited adaptive candidate search
   and *optional* external semantic evaluation; do not confuse rerunning
   the experiment with offline reconstruction of the 80 published labels.
4. Validate thresholds `0.13 / 0.14 / 0.20`, the source split and original
   image/checkpoint SHA-256s before comparing fresh results.
5. The independent optical stress test is in `notebooks/external_opi_200.ipynb`;
   it requires a separate dataset and is not pooled with the CyberSecEval3
   attack-success metrics.

**Known blocker for turnkey GPU reproduction:** the complete historical
restoration script is not among the release inputs here, so it is not bundled.
Upload it only after checking code ownership and dependencies. A source
notebook is not equivalent to a self-contained installable pipeline.

## Evaluation boundaries

- Primary 4-VLM study: 800 attack and 800 benign evaluations (different
  inference configuration; **raw full primary records not all packaged**).
- Spatial: 500 transformed attack inputs from 100 sources; separate setup.
- Budgeted adaptive: 80 source-disjoint inputs, max four full-cascade calls
  per source, with proposal and response-feedback proxies. It is **not**
  a fully success-gradient-optimized attacker.
- Model-only image validity should be treated as imperfect model evidence.
- The `LICENSE` file intentionally makes **no open-source license grant**
  until the owner picks one; see `LICENSE_MIT_TEMPLATE.txt`.

## Publishing safely

Do not commit `.pkl`, model weights, Kaggle caches, API tokens or third-party
images. For public repository publication, review the notebooks and CSV
files for third-party content, confidential prompts, credentials and licensing.
Only minimized results and ID lists are included in this ZIP. See `DATA.md`.

## Citation

**Manuscript currently under preparation.** Add the final DOI and BibTeX
record only after publication; do not claim IEEE TIFS acceptance beforehand.
