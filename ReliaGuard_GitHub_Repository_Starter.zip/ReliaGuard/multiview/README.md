# Four-view OCR screening

The original AD0C notebook cell implements original, trimmed and trimmed
+/-12-degree views; its code is retained in
`original_ad0c_notebook_cell.py` for source-level transparency.

`decision.py` provides a pure, tested max-aggregation rule. The original
scorer still needs OpenCV, the EasyOCR reader and frozen Stage-0 classifier.
