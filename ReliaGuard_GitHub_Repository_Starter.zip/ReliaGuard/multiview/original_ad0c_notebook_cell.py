# Original Stage-0 multi-view scorer, verbatim from AD0C notebook cell.
# Notebook-bound: expects original reader/stage0_model and related runtime globals.
# Do not import as a stand-alone production module; execute after runtime restoration.

# AD0C — Restore the EXACT Stage-0 four-view functions from vli-last2-0.ipynb cell 13
# These are definitions only; no target-VLM calls are performed.
import cv2, numpy as np, pandas as pd
def trim_white_margin(
    image,
    threshold=242,
    pad_fraction=0.02
):
    gray = cv2.cvtColor(
        image, cv2.COLOR_BGR2GRAY
    )

    ys, xs = np.where(gray < threshold)

    if len(ys) < 20:
        return image

    h, w = image.shape[:2]

    pad = max(
        3,
        int(min(h, w) * pad_fraction)
    )

    x1 = max(0, int(xs.min()) - pad)
    x2 = min(w, int(xs.max()) + pad + 1)

    y1 = max(0, int(ys.min()) - pad)
    y2 = min(h, int(ys.max()) + pad + 1)

    cropped = image[y1:y2, x1:x2]

    return (
        cropped
        if min(cropped.shape[:2]) >= 30
        else image
    )


def gate_probability(image):

    # Original extractor expects RGB for arrays,
    # but accepts a path directly.
    if isinstance(image, np.ndarray):
        image = cv2.cvtColor(
            image, cv2.COLOR_BGR2RGB
        )

    features = extract_ocr_layout_features(image)

    X = pd.DataFrame([{
        k: float(features[k])
        for k in FINAL_LAYOUT_FEATURES
    }])

    return float(
        stage0_model.predict_proba(X)[0, 1]
    )


def strengthened_gate(image_path):

    original = cv2.imread(str(image_path))

    assert original is not None

    cropped = trim_white_margin(original)

    views = {
        "original": original,
        "trimmed": cropped
    }

    for angle in [-12, 12]:

        h, w = cropped.shape[:2]

        M = cv2.getRotationMatrix2D(
            (w / 2, h / 2),
            angle, 1.0
        )

        ca = abs(M[0, 0])
        sa = abs(M[0, 1])

        bw = int(w * ca + h * sa)
        bh = int(w * sa + h * ca)

        M[0, 2] += bw / 2 - w / 2
        M[1, 2] += bh / 2 - h / 2

        rotated = cv2.warpAffine(
            cropped,
            M,
            (bw, bh),
            borderValue=(255, 255, 255)
        )

        views[f"rotation_{angle}"] = (
            trim_white_margin(rotated)
        )

    scores = {
        name: gate_probability(image)
        for name, image in views.items()
    }

    original_score = scores["original"]
    strengthened_score = max(scores.values())

    return (
        original_score,
        strengthened_score,
        scores
    )


print("Stage-0 gate functions ready.")
assert callable(strengthened_gate)
print('AD0C complete: single-view and four-view Stage-0 scorers ready.')

