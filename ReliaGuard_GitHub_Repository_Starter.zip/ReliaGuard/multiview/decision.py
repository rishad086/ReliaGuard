"""Frozen Stage-0 max-aggregation rule for four views."""
from stage0.decision import is_flagged

def aggregate_presence_scores(scores):
    scores=list(scores)
    if len(scores)!=4: raise ValueError('Expected exactly four scored views')
    return max(float(x) for x in scores)

def multiview_is_flagged(scores):
    return is_flagged(aggregate_presence_scores(scores))
