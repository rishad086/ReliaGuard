# V4: candidate-level risk and selective release

`decision.py` preserves the 0.20 **strict** acceptance threshold and the
minimum-risk selection semantics. `original_fc5_notebook_bridge.py` is the
actual full-cascade adapter from the frozen 80-source notebook; it requires
historical runtime globals and is not a stand-alone importable library.

The original feature builder, validity filtering and fitted checkpoint are
part of the historical runtime. They are not recreated with guessed features.
