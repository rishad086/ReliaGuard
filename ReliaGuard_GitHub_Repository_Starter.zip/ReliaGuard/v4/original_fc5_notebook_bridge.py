# Original FC5 full-cascade adapter copied from the historical notebook.
# Notebook-bound and requires restored frozen runtime, stage0_model, V3/V4 and VLM.

# FC5 — Exact original cascade with the multi-view Stage-0 score substituted;
# original V3/V4 classifiers, OCR interventions, validity, and thresholds unchanged.
class FrozenStage0Probability:
    def __init__(self,frozen_model,p): self.frozen_model,self.p=frozen_model,float(p)
    def predict_proba(self,X):
        proba=np.asarray(self.frozen_model.predict_proba(X),dtype=float).copy()
        assert proba.shape==(1,2)
        proba[0,1],proba[0,0]=self.p,1-self.p
        return proba

def run_frozen_mv_cascade(source,img,mv_score,original_response,tag):
    global stage0_model,run_target_vlm_on_image
    old_gate=stage0_model;old_runner=run_target_vlm_on_image
    record=dict(sample_id=int(source['sample_id']),image_path=str(img),
                user_prompt=source['user_prompt'],system_prompt=source['system_prompt'])
    def cached_runner(path,prompt,sys_prompt=''):
        if (str(path)==str(img) and str(prompt)==source['user_prompt'] and
            str(sys_prompt)==source['system_prompt']):return original_response
        return old_runner(path,prompt,sys_prompt)
    folder=ROOT_FC/'cascade'/str(source['sample_id'])/tag
    folder.mkdir(parents=True,exist_ok=True)
    try:
        stage0_model=FrozenStage0Probability(old_gate,mv_score)
        run_target_vlm_on_image=cached_runner
        result=run_full_cascade(record,save_dir=str(folder))
        keys=('sample_id','stage0_probability','stage0_flagged',
              'v3_compromise_probability','v3_compromised',
              'mask_valid','mask_p_unsafe','blur_valid','blur_p_unsafe',
              'inpaint_valid','inpaint_p_unsafe','selected_variant',
              'selected_unsafe_probability','released','abstained',
              'decision_path','original_response','mask_response',
              'blur_response','inpaint_response','final_response','num_vlm_calls',
              'total_end_to_end_ms')
        final={k:(result[k].item() if isinstance(result[k],np.generic) else result[k])
               for k in keys if k in result}
        final['input_sha256']=digest(img)
        final['queried_multi_stage0']=float(mv_score)
        return final
    finally:
        stage0_model=old_gate
        run_target_vlm_on_image=old_runner
        # These files are intermediate recomputable transformations. Scalar results,
        # transformed input images and hashes are preserved separately.
        shutil.rmtree(folder,ignore_errors=True)

print('Native cascade bridge ready. No predictor has been refit.')

