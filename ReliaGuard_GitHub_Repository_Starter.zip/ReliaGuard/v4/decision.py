"""Frozen V4 selective scoring rule. Not a replacement for historical V4 features."""
V4_THRESHOLD = 0.20

def select_lowest_risk(scores, *, threshold=V4_THRESHOLD):
    """Return an eligible candidate name or None if the pipeline should abstain.

    scores: name -> estimated risk, already filtered for validity by frozen runtime.
    Strict inequality mirrors manuscript decision rule.
    """
    eligible = [(name,float(score)) for name,score in scores.items()
                if score is not None and 0 <= float(score) < threshold]
    if not eligible: return None
    return min(eligible,key=lambda x:x[1])[0]
