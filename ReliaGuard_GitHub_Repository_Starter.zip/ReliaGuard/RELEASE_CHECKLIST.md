# Before making the repository public

- [ ] Confirm ownership, coauthor approval and institutional IP policy.
- [ ] Choose and install a real `LICENSE` (current file reserves rights).
- [ ] Export and review historical `restore_reliaguard_runtime.py` if full
      standalone reproduction is intended; commit only if permitted.
- [ ] Add verified checkpoint SHA-256s, exact source dataset revisions,
      VLM model revisions and deterministic seeds.
- [ ] Reproduce end-to-end inference on a fresh GPU using the intended setup.
- [ ] Freeze actual GPU software versions (historical Sep-2026 environment
      is not identical to every final October experiment).
- [ ] Add full primary 4-VLM/800-source aggregate and corresponding raw
      sanitized results **only after a provenance and license audit**.
- [ ] Make the 80-source model-only validity limitation unambiguous.
- [ ] Verify all tests and offline reported numbers.
- [ ] Check repository for accidentally committed secrets or personal data.
- [ ] Add paper DOI and final citation when accepted/published.
