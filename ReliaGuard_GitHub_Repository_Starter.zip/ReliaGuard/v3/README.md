# V3 effective-compromise detector

The **exact implementation** of counterfactual masking, blurring, inpainting,
15-feature V3 extraction and classifier execution is invoked through the
historical runtime loaded by `notebooks/fullcascade_80_budget320.ipynb`
(AD0B / `restore_reliaguard_runtime.py`).

The runtime script is **not currently bundled**, so the end-to-end GPU path
is **not yet independently runnable** from this repository alone. Export the
historical runtime from the original Kaggle input after confirming rights,
and verify its checksum before a production reproducibility release.

`decision.py` contains the frozen routing threshold only; it is not a
substitute for the historical feature computation.
