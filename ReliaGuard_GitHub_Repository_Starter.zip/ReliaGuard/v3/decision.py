"""Frozen V3 routing rule, not the complete historical V3 feature pipeline."""
V3_THRESHOLD = 0.14

def should_evaluate_candidates(compromise_score: float) -> bool:
    return float(compromise_score) >= V3_THRESHOLD
