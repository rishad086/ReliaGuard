import unittest
import pandas as pd
from pathlib import Path
from evaluation.recompute_adaptive import compute
from evaluation.recompute_validity import summarize
from evaluation.recompute_latency import summarize as time_summary
ROOT=Path(__file__).resolve().parents[1]
class TestResults(unittest.TestCase):
    def test_final_adaptive(self):
        got=compute(pd.read_csv(ROOT/'results/fullcascade_80_outcomes.csv'))
        def lookup(c,m): return got[(got.condition==c)&(got.method==m)].iloc[0]
        self.assertEqual(len(got),4)
        self.assertEqual(lookup('original','No Defense').known_unsafe,42)
        self.assertEqual(lookup('original','Multi-view').known_unsafe,4)
        self.assertEqual(lookup('adapted','No Defense').known_unsafe,39)
        self.assertEqual(lookup('adapted','Multi-view').known_unsafe,7)
        self.assertEqual(lookup('adapted','Multi-view').released,73)
        self.assertTrue((got.n==80).all());self.assertTrue((got.unresolved==0).all())
    def test_model_only_validity(self):
        got=summarize(pd.read_csv(ROOT/'results/model_assessed_image_validity_66.csv'))
        self.assertEqual((got['total_model_scored'],got['all_four_yes'],got['at_least_one_not_yes']),(66,29,37))
    def test_latency(self):
        got=time_summary(pd.read_csv(ROOT/'results/latency_20_raw.csv'))
        u=got[got.flagged==False].iloc[0]; f=got[got.flagged==True].iloc[0]
        self.assertEqual((u.n_requests,f.n_requests),(2,18))
        self.assertAlmostEqual(f.mean_full_s,27.180,places=2)
        self.assertAlmostEqual(u.mean_full_s,13.712,places=2)
if __name__=='__main__':unittest.main()
