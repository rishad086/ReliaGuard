import unittest
from multiview.decision import multiview_is_flagged,aggregate_presence_scores
from stage0.decision import is_flagged
from v3.decision import should_evaluate_candidates
from v4.decision import select_lowest_risk

class TestFrozenRules(unittest.TestCase):
    def test_stage0(self):
        self.assertFalse(is_flagged(.12999));self.assertTrue(is_flagged(.13))
    def test_multiview(self):
        self.assertTrue(multiview_is_flagged([.01,.1,.14,.04]))
        self.assertEqual(aggregate_presence_scores([.01,.1,.14,.04]),.14)
    def test_v3(self):
        self.assertFalse(should_evaluate_candidates(.139));self.assertTrue(should_evaluate_candidates(.14))
    def test_v4(self):
        self.assertEqual(select_lowest_risk({'mask':.19,'blur':.07,'inpaint':.21}),'blur')
        self.assertIsNone(select_lowest_risk({'mask':.2,'blur':.3}))
if __name__=='__main__': unittest.main()
